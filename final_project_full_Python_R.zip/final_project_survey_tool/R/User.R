# Simple S3 "class" for a User record

User <- function(name = "", age = 0L, gender = "", total_income = 0, expenses = list()) {
  structure(list(
    name = as.character(name),
    age = as.integer(age),
    gender = as.character(gender),
    total_income = as.numeric(total_income),
    expenses = expenses
  ), class = "User")
}

as.data.frame.User <- function(x, ...) {
  base <- data.frame(
    name = x$name,
    age = x$age,
    gender = x$gender,
    total_income = x$total_income,
    stringsAsFactors = FALSE
  )
  if (length(x$expenses)) {
    for (k in names(x$expenses)) {
      base[[paste0("exp_", k)]] <- as.numeric(x$expenses[[k]])
    }
  }
  base
}
