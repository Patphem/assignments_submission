# R Version (Data Export + Analysis)

This folder provides an **R path** for the assignment:

1. **Data Export from MongoDB to CSV**: `export_csv.R` (uses `mongolite`).
2. **User "class" (S3)**: `User.R` (constructor + helper to normalize).
3. **Analysis Notebook**: `Analysis.Rmd` (R Markdown) and `Analysis.R` (plain R script) that
   - loads the CSV from `../exports/survey_data.csv`,
   - creates the required charts,
   - saves them to `../exports/ages_highest_income.png` and `../exports/gender_spend_by_category.png`.

## Packages

```r
install.packages(c("mongolite","tidyverse","readr","ggplot2","tidyr","dplyr","knitr","rmarkdown"))
```

## 1) Export data to CSV

Set env vars in your shell (or edit the placeholders in `export_csv.R`):

- `MONGODB_URI`
- `DB_NAME` (default: `final_project_db`)
- `COLLECTION_NAME` (default: `survey_responses`)

Then run:
```r
source("R/export_csv.R")
```

## 2) Run the analysis

Use the R Markdown notebook:
```r
rmarkdown::render("R/Analysis.Rmd")
```

Or the plain script:
```r
source("R/Analysis.R")
```

Charts will be written to `exports/` for PowerPoint use.
