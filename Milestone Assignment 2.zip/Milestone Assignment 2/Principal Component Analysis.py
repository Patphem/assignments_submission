
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score

# --- 2. Load Data ---
data_file = r"C:\Users\Orowole\Downloads\data.csv"
df = pd.read_csv(data_file)

# --- 3. Data Cleaning: Remove index/id/unnamed columns if present ---
df = df.loc[:, ~df.columns.str.contains('^Unnamed')]
if 'id' in df.columns:
    df = df.drop(columns=['id'])

# --- 4. Check for NaNs ---
print("Missing values per column:\n", df.isna().sum())

# --- 5. Separate features and target ---
X = df.drop(columns=['diagnosis'])
y = df['diagnosis'].map({'M':1, 'B':0})  # Convert target to binary

# --- 6. Impute missing values (if any) ---
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)
X = pd.DataFrame(X_imputed, columns=X.columns)

# --- 7. Feature Scaling ---
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# --- 8. PCA for 2D visualization (optional) ---
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:,0], X_pca[:,1], c=y, cmap='bwr', alpha=0.5)
plt.title('PCA of Breast Cancer Features')
plt.xlabel('PC1')
plt.ylabel('PC2')
plt.show()

# --- 9. Train-Test Split ---
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

# --- 10. Model Training ---
model = LogisticRegression(max_iter=2000)
model.fit(X_train, y_train)

# --- 11. Evaluation ---
y_pred = model.predict(X_test)
print("\nAccuracy: {:.3f}".format(accuracy_score(y_test, y_pred)))
print("\nClassification Report:\n", classification_report(y_test, y_pred))
print("\nConfusion Matrix:\n", confusion_matrix(y_test, y_pred))

# --- 12. Feature Importance ---
feature_names = X.columns
print(f"feature_names: {list(feature_names)}")
print(f"coef length: {len(model.coef_[0])}")

if len(model.coef_[0]) == len(feature_names):
    feature_importance = pd.Series(abs(model.coef_[0]), index=feature_names)
    feature_importance = feature_importance.sort_values(ascending=False)
    plt.figure(figsize=(10, 5))
    sns.barplot(x=feature_importance.values[:10], y=feature_importance.index[:10])
    plt.title("Top 10 Most Important Features")
    plt.xlabel("Importance (abs coef)")
    plt.tight_layout()
    plt.show()
else:
    print("❗️Feature/coef mismatch. Please check preprocessing steps.")

# --- 13. Save predictions (optional) ---
output_df = X.copy()
output_df['true_label'] = y.values
output_df['pred_label'] = model.predict(X_scaled)
output_df.to_csv("breast_cancer_predictions.csv", index=False)
print("Prediction file saved as 'breast_cancer_predictions.csv'")
