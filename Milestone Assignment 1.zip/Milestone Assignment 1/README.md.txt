README.md
# Policy Management System for Insurance Company

## Files

- `policyholder.py`: Contains the Policyholder class and methods.
- `product.py`: Contains the Product class and management methods.
- `payment.py`: Contains the Payment class for processing, reminders, and penalties.
- `demo.py`: Demonstrates the system as required.

## How to Run

1. Place all `.py` files in the same directory.
2. Run `demo.py`:
3. The script demonstrates registering policyholders, assigning products, processing payments, and showing account details, as well as managing policyholder and product status.

## Assignment Coverage

- Each class is in its own file.
- All required management and processing methods are implemented.
- Demonstration includes at least two policyholders and their payment/account details.

