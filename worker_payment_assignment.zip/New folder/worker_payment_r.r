# Worker Payment Slip Generator in R

# Set seed for reproducibility
set.seed(42)

# Number of workers
num_workers <- 400

# Generate worker data dynamically
ids <- sprintf("W%03d", 1:num_workers)
names <- paste0("Worker_", 1:num_workers)
genders <- sample(c("male", "female"), num_workers, replace=TRUE)
salaries <- round(runif(num_workers, 6000, 32000), 2)

# Assign Employee Level based on salary and gender
get_employee_level <- function(salary, gender) {
  if (!is.numeric(salary) || is.na(salary)) {
    return("Unknown")
  }
  # A1 condition
  if (salary > 10000 && salary < 20000) {
    return("A1")
  }
  # A5-F condition
  if (salary > 7500 && salary < 30000 && gender == "female") {
    return("A5-F")
  }
  return("Standard")
}

employee_level <- mapply(get_employee_level, salaries, genders)

# Combine into a data frame
workers <- data.frame(
  id = ids,
  name = names,
  gender = genders,
  salary = salaries,
  employee_level = employee_level,
  stringsAsFactors = FALSE
)

# Generate payment slips
for (i in 1:nrow(workers)) {
  cat("Payment Slip for", workers$name[i], "(ID:", workers$id[i], "):\n")
  cat("  Gender:", workers$gender[i], "\n")
  cat("  Salary: $", workers$salary[i], "\n")
  cat("  Employee Level:", workers$employee_level[i], "\n")
  cat(strrep("-", 30), "\n")
}


