# Salary Data Processing Assignment

## Overview
This project demonstrates data processing, error handling, file handling in Python, and basic data handling in R.  
It fulfills all requirements as specified in the assignment instructions.

## Contents

- `salary_processing.ipynb` — Jupyter Notebook with all Python code
- `unzip_and_display.R` — R script to unzip the folder and display exported employee data
- `Employee Profile.zip` — (Generated) Zipped folder containing exported employee profiles in CSV format

## How to Run

### Python Steps

1. **Open `salary_processing.ipynb` in Jupyter Notebook or VS Code.**
2. **Update the file path** in the code if your salary CSV is located elsewhere:
   ```python
   salary_file = r"C:\Users\Orowole\Downloads\Total.csv\Total.csv"
