# Netflix Data Visualization Assignment
# Author: Oluwafemi Patrick, Orowole
# Date: 7th of August, 2025

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

# --- 1. Data Preparation ---
csv_path = r"C:\Users\Orowole\Downloads\netflix_data.csv"  
assert os.path.exists(csv_path), f"File not found: {csv_path}"

# --- 2. Data Cleaning ---
df = pd.read_csv(csv_path)
print("Original shape:", df.shape)
print("Columns:", df.columns.tolist())
print("\nMissing values per column:\n", df.isnull().sum())

# Example cleaning (update field names based on CSV structure)
# Fill missing 'genre' and 'rating' if present
if 'genre' in df.columns:
    df['genre'] = df['genre'].fillna('Unknown')
if 'rating' in df.columns:
    df['rating'] = df['rating'].fillna('Unknown')
# Drop rows with excessive missing values (optional)
df = df.dropna(thresh=int(df.shape[1] * 0.8))
print("After cleaning:", df.shape)

# --- 3. Data Exploration ---
print("\nFirst 5 rows:\n", df.head())
print("\nUnique genres:", df['genre'].unique() if 'genre' in df.columns else "N/A")
print("Unique ratings:", df['rating'].unique() if 'rating' in df.columns else "N/A")

if 'genre' in df.columns:
    print("\nMost watched genres:\n", df['genre'].value_counts())
if 'rating' in df.columns:
    print("\nRatings distribution:\n", df['rating'].value_counts())

# --- 4. Data Visualization ---
plt.style.use('ggplot')
# Genre visualization
if 'genre' in df.columns:
    plt.figure(figsize=(10,6))
    top_genres = df['genre'].value_counts().head(10)
    sns.barplot(y=top_genres.index, x=top_genres.values, palette='viridis')
    plt.title('Top 10 Most Watched Genres')
    plt.xlabel('Number of Shows/Movies')
    plt.ylabel('Genre')
    plt.tight_layout()
    plt.savefig("most_watched_genres.png")
    plt.show()

# Ratings distribution
if 'rating' in df.columns:
    plt.figure(figsize=(8,5))
    sns.countplot(x='rating', data=df, order=df['rating'].value_counts().index, palette='magma')
    plt.title('Ratings Distribution')
    plt.xlabel('Rating')
    plt.ylabel('Count')
    plt.tight_layout()
    plt.savefig("ratings_distribution.png")
    plt.show()

print("\nCharts saved: 'most_watched_genres.png' and 'ratings_distribution.png'")
