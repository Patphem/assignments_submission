# Fashion MNIST Image Classification using a CNN

## Project Overview

This project implements a 6-layer Convolutional Neural Network (CNN) to classify images from the Fashion MNIST dataset. The model is built using TensorFlow and Keras. The primary goal is to demonstrate the process of building, training, and evaluating a CNN for a multi-class image classification task.

This work was completed as an assignment simulating a junior machine learning researcher's task at Microsoft AI, with the long-term goal of adapting such models for user profile classification in targeted marketing.

## Features

-   **Dataset:** Fashion MNIST (10 classes of clothing items).
-   **Model:** A 6-layer CNN architecture (Conv -> Pool -> Conv -> Pool -> Flatten -> Dense).
-   **Frameworks:** TensorFlow, Keras, NumPy.
-   **Functionality:**
    -   Loads and preprocesses the dataset.
    -   Builds, compiles, and trains the CNN model.
    -   Evaluates the model on the test set to measure accuracy.
    -   Makes and visualizes predictions on sample images from the test set.

## Technologies Used

-   **Python:** 3.11
-   **TensorFlow:** 2.12+
-   **NumPy:** For numerical operations.
-   **Matplotlib:** For data visualization and saving prediction results.

## Setup and Installation

To run this project locally, please follow these steps.

1.  **Clone the repository (if applicable):**
    ```bash
    git clone <your-repository-link>
    cd <repository-name>
    ```

2.  **Create and activate a Python virtual environment:**
    ```bash
    # Create the environment
    python3 -m venv .venv

    # Activate it (macOS/Linux)
    source .venv/bin/activate

    # Activate it (Windows)
    .\.venv\Scripts\activate
    ```

3.  **Install the required dependencies:**
    ```bash
    pip install -r requirements.txt
    ```
    *(Note: You will need to create a `requirements.txt` file by running `pip freeze > requirements.txt` after installing the packages below, or simply run the command below.)*
    ```bash
    pip install tensorflow numpy matplotlib
    ```

## How to Run

Once the setup is complete, you can run the main script from the root of the project directory:

```bash
python fashion_mnist_cnn.py
```

The script will:
1.  Print the model architecture and training progress to the console.
2.  Display the final test accuracy and loss.
3.  Create an `assets/` directory.
4.  Save two images with prediction results (`prediction_1.png`, `prediction_2.png`) inside the `assets/` directory.

## Project Structure

```
.
├── assets/
│   ├── prediction_1.png
│   └── prediction_2.png
├── .venv/
├── fashion_mnist_cnn.py
└── README.md
```

-   `assets/`: Contains the output images of the model's predictions.
-   `fashion_mnist_cnn.py`: The main Python script containing the entire workflow.
-   `README.md`: This file.

## Results

The model was trained for 10 epochs and achieved the following performance on the test set:

-   **Test Accuracy:** ~91.2%
-   **Test Loss:** ~0.25

*Note: Your results may vary slightly due to the random initialization of model weights.*