README.md

# Breast Cancer Classification (Python)

This notebook performs classification on the breast cancer diagnostic dataset.  
Steps include:
- Data cleaning (removes unwanted columns, handles NaNs)
- Feature engineering and scaling
- PCA visualization
- Logistic regression model training and evaluation
- Feature importance plotting

## Usage
1. Download your data to:  
   `C:\Users\Orowole\Downloads\data.csv`
2. Open and run this notebook in Jupyter/VS Code.
3. Outputs and predictions will be displayed and saved as `breast_cancer_predictions.csv`.

## Requirements
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn

## Notes
- Ensure there are no missing values. The script imputes them with the mean if any are found.
- Feature importance is shown for the top 10 features.
