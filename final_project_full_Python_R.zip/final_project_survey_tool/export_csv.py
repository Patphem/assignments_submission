# Convenience script to dump Mongo data to CSV
from user_processing import users_to_csv
import os
os.makedirs("exports", exist_ok=True)
df = users_to_csv("exports/survey_data.csv")
print(df.head())
