from flask import Flask, render_template, request, redirect, url_for, flash
from pymongo import MongoClient
from dotenv import load_dotenv
import os
from datetime import datetime

load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI")
DB_NAME = os.getenv("DB_NAME", "final_project_db")
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "survey_responses")
SECRET_KEY = os.getenv("FLASK_SECRET_KEY", "dev-secret")

app = Flask(__name__)
app.secret_key = SECRET_KEY

# Mongo Client (lazy connect when first used)
client = MongoClient(MONGODB_URI) if MONGODB_URI else None
db = client[DB_NAME] if client else None
col = db[COLLECTION_NAME] if db else None

# Expense categories we support (checkbox + amount)
EXPENSE_CATEGORIES = [
    "utilities", "entertainment", "school_fees", "shopping", "healthcare"
]

def parse_expenses(form) -> dict:
    expenses = {}
    for cat in EXPENSE_CATEGORIES:
        checked = form.get(f"exp_{cat}")  # "on" if checked
        amount_str = form.get(f"amt_{cat}", "").strip()
        amount = None
        if amount_str:
            try:
                amount = float(amount_str.replace(",", ""))
            except ValueError:
                amount = None
        if checked or (amount is not None):
            # Store only if either checked or amount entered
            expenses[cat] = amount if amount is not None else 0.0
    return expenses

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html", categories=EXPENSE_CATEGORIES)

@app.route("/submit", methods=["POST"])
def submit():
    # Basic validation
    name = request.form.get("name", "").strip()
    age = request.form.get("age", "").strip()
    gender = request.form.get("gender", "").strip()
    income = request.form.get("income", "").strip()

    if not age or not gender or not income:
        flash("Age, Gender and Total Income are required.", "error")
        return redirect(url_for("index"))

    try:
        age = int(age)
    except ValueError:
        flash("Age must be an integer.", "error")
        return redirect(url_for("index"))

    try:
        income = float(income.replace(",", ""))
    except ValueError:
        flash("Total Income must be numeric.", "error")
        return redirect(url_for("index"))

    expenses = parse_expenses(request.form)

    doc = {
        "name": name or None,
        "age": age,
        "gender": gender,
        "total_income": income,
        "expenses": expenses,
        "created_at": datetime.utcnow()
    }

    if not col:
        flash("MongoDB is not configured. Please set MONGODB_URI.", "error")
        return redirect(url_for("index"))

    col.insert_one(doc)
    return render_template("success.html")

if __name__ == "__main__":
    # For local development
    app.run(host="0.0.0.0", port=5000, debug=True)
