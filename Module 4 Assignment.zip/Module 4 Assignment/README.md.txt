README.md

# Netflix Data Visualization Assignment

## Overview
This project utilizes Python and R to analyze Netflix show/movie data, with a focus on genre and ratings analytics.

## Steps to Run

1. Ensure `netflix_data.csv` is in your working directory.
2. Run `netflix_analysis.py` in Python (Jupyter or VSCode) to:
    - Clean and explore the data
    - Produce charts: `most_watched_genres.png` and `ratings_distribution.png`
3. Run `netflix_visualization.R` in RStudio or VSCode to see a genre chart in R.

## Requirements

- Python: pandas, matplotlib, seaborn
- R: ggplot2

## Output

- Data cleaning summaries in the console
- Top 10 genres and ratings charts as PNG images
