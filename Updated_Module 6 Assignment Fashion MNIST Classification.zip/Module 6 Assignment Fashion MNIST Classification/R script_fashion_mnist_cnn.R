

suppressPackageStartupMessages({
  library(keras)
})

# 1) Load data
fashion <- dataset_fashion_mnist()
c(c(x_train, y_train), c(x_test, y_test)) %<-% fashion

# 2) Preprocess
x_train <- x_train / 255
x_test  <- x_test  / 255

# Add channel dimension (N, 28, 28, 1)
x_train <- array_reshape(x_train, c(nrow(x_train), 28, 28, 1))
x_test  <- array_reshape(x_test,  c(nrow(x_test),  28, 28, 1))

# One-hot targets
num_classes <- 10L
y_train <- to_categorical(y_train, num_classes)
y_test  <- to_categorical(y_test,  num_classes)

# 3) Build model (>=6 trainable layers)
model <- keras_model_sequential() |>
  layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = "relu", input_shape = c(28,28,1)) |>
  layer_batch_normalization() |>
  layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = "relu") |>
  layer_max_pooling_2d(pool_size = c(2,2)) |>
  layer_dropout(0.25) |>
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = "relu") |>
  layer_batch_normalization() |>
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = "relu") |>
  layer_max_pooling_2d(pool_size = c(2,2)) |>
  layer_dropout(0.25) |>
  layer_flatten() |>
  layer_dense(units = 128, activation = "relu") |>
  layer_batch_normalization() |>
  layer_dropout(0.5) |>
  layer_dense(units = num_classes, activation = "softmax")

model |> compile(
  optimizer = "adam",
  loss = "categorical_crossentropy",
  metrics = c("accuracy")
)

summary(model)

# 4) Train
batch_size <- 128
epochs <- 8

history <- model |> fit(
  x = x_train, y = y_train,
  batch_size = batch_size,
  epochs = epochs,
  validation_split = 0.1,
  verbose = 2
)

# 5) Evaluate
scores <- model |> evaluate(x_test, y_test, verbose = 0)
cat(sprintf("\nTest loss: %.4f  •  Test accuracy: %.4f\n", scores["loss"], scores["accuracy"]))

# 6) Predict at least 2 images and save outputs
class_names <- c("T-shirt/top","Trouser","Pullover","Dress","Coat",
                 "Sandal","Shirt","Sneaker","Bag","Ankle boot")

pred_idx <- c(1, 2, 3, 4, 5)  # sample a few
pred <- model |> predict(x_test[pred_idx,,,], verbose = 0)
pred_labels <- apply(pred, 1, which.max) - 1L

# Save simple CSV of predictions
out <- data.frame(
  index = pred_idx,
  predicted_id = pred_labels,
  predicted_label = class_names[pred_labels + 1L],
  true_id = apply(y_test[pred_idx,], 1, which.max) - 1L,
  true_label = class_names[apply(y_test[pred_idx,], 1, which.max)]
)
write.csv(out, "r_predictions.csv", row.names = FALSE)
cat("Saved predictions to r_predictions.csv\n")

# 7) Save model
dir.create("r_saved_model", showWarnings = FALSE)
save_model_tf(model, "r_saved_model/fashion_mnist_cnn")
cat("Saved TensorFlow SavedModel to r_saved_model/fashion_mnist_cnn\n")

# Optional: plot training history if interactive session
if (interactive()) {
  plot(history)
}
