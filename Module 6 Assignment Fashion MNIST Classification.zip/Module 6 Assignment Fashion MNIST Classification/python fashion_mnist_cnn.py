"""
Fashion-MNIST CNN Classifier
--------------------------
This script builds, trains, and evaluates a 6-layer Convolutional Neural Network
to classify images from the Fashion MNIST dataset using TensorFlow and Keras.

It performs the following steps:
1. Loads and preprocesses the Fashion MNIST data.
2. Defines and compiles a 6-layer CNN model.
3. Trains the model on the training data.
4. Evaluates the model's performance on the test data.
5. Makes predictions on two sample images and saves the results as PNG files.
"""

import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
import matplotlib.pyplot as plt

# --- 0. Setup and Constants ---
# Define class names for the 10 categories
CLASS_NAMES = ['T-shirt/top', 'Trouser', 'Pullover', 'Dress', 'Coat',
               'Sandal', 'Shirt', 'Sneaker', 'Bag', 'Ankle boot']

# Image dimensions
IMG_WIDTH = 28
IMG_HEIGHT = 28

# Create a directory to save prediction assets
if not os.path.exists('assets'):
    os.makedirs('assets')

# --- 1. Load and Preprocess Data ---
print("Step 1: Loading and preprocessing data...")
(x_train, y_train), (x_test, y_test) = keras.datasets.fashion_mnist.load_data()

# Reshape data to include channel dimension (1 for grayscale)
x_train = x_train.reshape(x_train.shape[0], IMG_WIDTH, IMG_HEIGHT, 1)
x_test = x_test.reshape(x_test.shape[0], IMG_WIDTH, IMG_HEIGHT, 1)
input_shape = (IMG_WIDTH, IMG_HEIGHT, 1)

# Normalize pixel values from [0, 255] to [0, 1]
x_train = x_train.astype('float32') / 255.0
x_test = x_test.astype('float32') / 255.0

# One-hot encode the labels
y_train = keras.utils.to_categorical(y_train, 10)
y_test = keras.utils.to_categorical(y_test, 10)

print(f"Data preprocessed. Training data shape: {x_train.shape}, Test data shape: {x_test.shape}")

# --- 2. Build the 6-Layer CNN Model ---
print("\nStep 2: Building the 6-layer CNN model...")
model = keras.Sequential([
    # Layer 1: Convolutional layer with 32 filters
    keras.layers.Conv2D(32, kernel_size=(3, 3), activation='relu', input_shape=input_shape),

    # Layer 2: Max Pooling layer to downsample
    keras.layers.MaxPooling2D(pool_size=(2, 2)),

    # Layer 3: Second Convolutional layer with 64 filters
    keras.layers.Conv2D(64, kernel_size=(3, 3), activation='relu'),

    # Layer 4: Second Max Pooling layer
    keras.layers.MaxPooling2D(pool_size=(2, 2)),

    # Layer 5: Flatten layer to transition to dense layers
    keras.layers.Flatten(),

    # Layer 6: Dense output layer for classification (10 classes)
    keras.layers.Dense(10, activation='softmax')
])

# --- 3. Compile the Model ---
print("Step 3: Compiling the model...")
model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

model.summary()

# --- 4. Train the Model ---
print("\nStep 4: Training the model...")
history = model.fit(x_train, y_train,
                    batch_size=128,
                    epochs=10,
                    validation_data=(x_test, y_test))

# --- 5. Evaluate the Model ---
print("\nStep 5: Evaluating the model on test data...")
test_loss, test_acc = model.evaluate(x_test, y_test, verbose=2)
print(f'\nTest accuracy: {test_acc:.4f}')
print(f'Test loss: {test_loss:.4f}')

# --- 6. Make Predictions for at Least Two Images ---
print("\nStep 6: Making predictions on two sample images...")

# Select two images from the test set for prediction
image_indices = [0, 7] # You can change these indices

for i, index in enumerate(image_indices):
    # Get the image and its true label
    sample_image = x_test[index]
    true_label_one_hot = y_test[index]
    true_label_index = np.argmax(true_label_one_hot)
    true_label_name = CLASS_NAMES[true_label_index]

    # The model expects a batch of images, so we add a dimension
    image_for_prediction = np.expand_dims(sample_image, axis=0)

    # Make the prediction
    predictions = model.predict(image_for_prediction)
    predicted_label_index = np.argmax(predictions[0])
    predicted_label_name = CLASS_NAMES[predicted_label_index]

    # Visualize the result
    plt.figure()
    plt.imshow(sample_image.squeeze(), cmap=plt.cm.binary)
    plt.title(f'Prediction {i+1}\nTrue: {true_label_name}\nPredicted: {predicted_label_name}')
    plt.xticks([])
    plt.yticks([])

    # Save the prediction image
    output_path = os.path.join('assets', f'prediction_{i+1}.png')
    plt.savefig(output_path)
    print(f"Saved prediction result to {output_path}")

plt.show() # Display the plots after saving

print("\nAssignment completed successfully.")