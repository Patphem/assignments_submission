# Export MongoDB survey data to CSV using R
# Requires: mongolite, tidyverse (readr), jsonlite

library(mongolite)
library(jsonlite)
library(readr)

# Read env or use defaults
mongo_uri <- Sys.getenv("MONGODB_URI", unset = "mongodb+srv://<user>:<password>@<cluster-host>/<db>?retryWrites=true&w=majority")
db_name   <- Sys.getenv("DB_NAME", unset = "final_project_db")
coll_name <- Sys.getenv("COLLECTION_NAME", unset = "survey_responses")

# Connect
con <- mongo(collection = coll_name, url = mongo_uri, db = db_name)

# Fetch all docs
docs <- con$find('{}')

# Normalize: flatten expenses map into columns prefixed exp_
normalize_docs <- function(df) {
  if (!"expenses" %in% names(df)) {
    return(df)
  }
  # Expand expenses list-column to wide
  # Convert NULL/NA to 0
  exp_list <- lapply(df$expenses, function(x) {
    if (is.null(x) || length(x) == 0) return(list())
    x
  })
  # Get all unique keys
  keys <- sort(unique(unlist(lapply(exp_list, names))))
  for (k in keys) {
    col <- sapply(exp_list, function(x) ifelse(!is.null(x[[k]]), as.numeric(x[[k]]), NA_real_))
    df[[paste0("exp_", k)]] <- col
  }
  df$expenses <- NULL
  df
}

out <- normalize_docs(docs)

# Keep core fields if present
# name, age, gender, total_income
if (!"name" %in% names(out)) out$name <- NA_character_
if (!"age" %in% names(out)) out$age <- NA_integer_
if (!"gender" %in% names(out)) out$gender <- NA_character_
if (!"total_income" %in% names(out)) out$total_income <- NA_real_

# Write CSV
dir.create("../exports", showWarnings = FALSE, recursive = TRUE)
write_csv(out, "../exports/survey_data.csv")
cat("Wrote CSV to ../exports/survey_data.csv with", nrow(out), "rows\n")
