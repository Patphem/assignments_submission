import random

def generate_workers(num_workers=400):
    """Dynamically generates a list of worker dictionaries."""
    workers = []
    for i in range(1, num_workers + 1):
        worker = {
            'id': f'W{i:03}',
            'name': f'Worker_{i}',
            'gender': random.choice(['male', 'female']),
            'salary': round(random.uniform(6000, 32000), 2)
        }
        workers.append(worker)
    return workers

def get_employee_level(worker):
    """Assigns Employee level based on salary and gender."""
    try:
        salary = worker['salary']
        gender = worker['gender']
        # A1 condition
        if 10000 < salary < 20000:
            return 'A1'
        # A5-F condition
        if 7500 < salary < 30000 and gender == 'female':
            return 'A5-F'
        return 'Standard'
    except Exception as e:
        print(f"Error assigning level for worker {worker['id']}: {e}")
        return 'Unknown'

def generate_payment_slips(workers):
    """Generates and prints payment slips for each worker."""
    for worker in workers:
        try:
            emp_level = get_employee_level(worker)
            print(f"Payment Slip for {worker['name']} (ID: {worker['id']}):")
            print(f"  Gender: {worker['gender'].title()}")
            print(f"  Salary: ${worker['salary']}")
            print(f"  Employee Level: {emp_level}")
            print("-" * 30)
        except Exception as err:
            print(f"Error processing worker {worker['id']}: {err}")

if __name__ == "__main__":
    workers = generate_workers()
    generate_payment_slips(workers)

