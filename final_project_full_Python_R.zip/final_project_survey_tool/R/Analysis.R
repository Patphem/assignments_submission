# Plain R analysis script to generate required charts from CSV
library(readr)
library(dplyr)
library(tidyr)
library(ggplot2)

csv_path <- "../exports/survey_data.csv"
df <- read_csv(csv_path, show_col_types = FALSE)

# 1) Ages with highest average income (Top 10)
age_income <- df %>%
  group_by(age) %>%
  summarize(avg_income = mean(total_income, na.rm = TRUE), .groups = "drop") %>%
  arrange(desc(avg_income)) %>%
  slice_head(n = 10)

p1 <- ggplot(age_income, aes(x = factor(age), y = avg_income)) +
  geom_col() +
  labs(title = "Ages with Highest Average Income (Top 10)",
       x = "Age", y = "Average Income")
dir.create("../exports", showWarnings = FALSE, recursive = TRUE)
ggsave("../exports/ages_highest_income.png", p1, width = 8, height = 5, dpi = 150)

# 2) Gender distribution across spending categories (total spend per category)
exp_cols <- grep("^exp_", names(df), value = TRUE)
if (length(exp_cols) > 0) {
  melted <- df %>%
    select(all_of(c("gender", exp_cols))) %>%
    pivot_longer(cols = all_of(exp_cols), names_to = "category", values_to = "amount") %>%
    mutate(category = gsub("^exp_", "", category),
           amount = ifelse(is.na(amount), 0, amount)) %>%
    group_by(gender, category) %>%
    summarize(total_spend = sum(amount, na.rm = TRUE), .groups = "drop")
  
  p2 <- ggplot(melted, aes(x = category, y = total_spend, fill = gender)) +
    geom_col(position = "dodge") +
    labs(title = "Gender Distribution Across Spending Categories (Total Spend)",
         x = "Category", y = "Total Spend")
  ggsave("../exports/gender_spend_by_category.png", p2, width = 9, height = 5, dpi = 150)
} else {
  message("No expense columns were found in CSV (columns prefixed with 'exp_').")
}
