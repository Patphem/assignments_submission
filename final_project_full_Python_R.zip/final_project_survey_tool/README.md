# Final Project – Survey Tool (Flask + MongoDB + Python/R Analysis)

This repository implements the assignment exactly as described:

1. **Web (Flask):** Simple webpage to collect Age, Gender, Total Income, and Expenses (checkboxes + amount per category).
2. **Data storage (MongoDB):** Submissions are written to MongoDB.
3. **Data processing (Python):** A `User` class and scripts to export data to CSV.
4. **Data viz (Jupyter):** Notebook that loads the CSV and produces the required charts, saved as PNG for PowerPoint.
5. **Deployment (AWS):** Steps below to host the Flask app on AWS.

---

## Project Structure

```
final_project_survey_tool/
├── app.py
├── requirements.txt
├── .env.example
├── templates/
│   ├── index.html
│   └── success.html
├── user_processing.py
├── export_csv.py
├── DataAnalysis.ipynb
├── exports/                # CSV & chart images will be saved here
└── static/
```

---

## 1) Run Locally

### Prereqs
- Python 3.10+
- MongoDB Atlas account (recommended) or local MongoDB
- Create `.env` from `.env.example` and fill:
  - `MONGODB_URI`
  - `DB_NAME`
  - `COLLECTION_NAME`
  - `FLASK_SECRET_KEY`

### Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env   # then edit .env
python app.py
```

Open `http://localhost:5000` to use the form.

---

## 2) Data → CSV

After collecting some responses, export to CSV:

```bash
python export_csv.py
# writes exports/survey_data.csv
```

---

## 3) Analysis in Jupyter

Open `DataAnalysis.ipynb` in Jupyter, run all cells. It will:
- Load `exports/survey_data.csv`
- Create **Ages with Highest Income** bar chart
- Create **Gender Distribution Across Spending Categories** chart
- Save images to `exports/ages_highest_income.png` and `exports/gender_spend_by_category.png` for PowerPoint

---

## 4) Deployment on AWS (Elastic Beanstalk quick path)

1. Install the EB CLI:
   ```bash
   pip install awsebcli
   ```
2. Initialize:
   ```bash
   eb init --platform python-3.12 --region us-east-1
   ```
3. Create an environment:
   ```bash
   eb create survey-tool-env
   ```
4. Set environment variables (from your `.env`) in AWS Console → Elastic Beanstalk → Configuration → Software:
   - `MONGODB_URI`
   - `DB_NAME`
   - `COLLECTION_NAME`
   - `FLASK_SECRET_KEY`
5. Deploy:
   ```bash
   eb deploy
   ```
6. Visit the environment URL.

**Alternative:** Use AWS Lightsail or an EC2 instance and run `gunicorn` behind Nginx.

---

## 5) Notes for Graders

- **Web form**: `index.html` collects all required fields and categories via checkboxes with per-category amount inputs.
- **MongoDB**: All submissions are stored with timestamp.
- **Processing**: `User` class in `user_processing.py`; `export_csv.py` creates CSV.
- **Visualization**: `DataAnalysis.ipynb` produces and saves both charts in `exports/`.
- **PowerPoint**: Charts are exported as PNG, ready to insert into slides.

---

## Optional (R Path)

If R is preferred for analysis, export the CSV as above and analyze with an R notebook using `ggplot2`. (Not included in this scaffold.)
