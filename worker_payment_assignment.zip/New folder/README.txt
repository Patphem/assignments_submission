# Worker Payment Slip Generator

## Overview
This program dynamically generates payment slips for at least 400 workers with random data (salary, gender, etc.), assigns employee levels based on salary and gender according to the conditions in the assignment, and demonstrates exception handling.

## How to Run (Python)
1. Ensure Python 3 is installed.
2. Save the script as `worker_payment.py`.
3. Open a terminal or command prompt.
4. Run: `python worker_payment.py`

## Assignment Logic
- Worker list is generated dynamically using a loop.
- For each worker:
    - Salary and gender are assigned randomly.
    - Conditional logic assigns 'A1', 'A5-F', or 'Standard' employee levels.
- Exception handling is included in key functions.

## Converting to R
Convert the logic to R by creating a similar worker list (using data.frame), iterating, and applying the salary/gender logic.

## Submission
- Zip the Python file and this README for upload.
- For GitHub: Create a repository, upload the zipped file (or the script and README separately).
