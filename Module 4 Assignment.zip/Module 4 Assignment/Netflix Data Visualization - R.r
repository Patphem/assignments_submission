# Netflix Data Visualization - R Chart Integration

library(ggplot2)

# Read the data (adjust path as needed)
df <- read.csv(
  "C:/Users/Orowole/Downloads/netflix_data.csv",
  stringsAsFactors = FALSE
)

# Plot Top 10 Most Watched Genres
if ("genre" %in% names(df)) {
  genre_counts <- as.data.frame(table(df$genre))
  top_genres <- head(genre_counts[order(-genre_counts$Freq), ], 10)
  
  ggplot(top_genres, aes(x=reorder(Var1, Freq), y=Freq, fill=Var1)) +
    geom_bar(stat="identity", show.legend=FALSE) +
    coord_flip() +
    labs(title="Top 10 Most Watched Genres (R Version)", x="Genre", y="Count")
}
