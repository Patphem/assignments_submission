# user_processing.R
# R version of User data export and processing

library(mongolite)
library(dplyr)
library(readr)

# Load environment variables
dotenv::load_dot_env(".env")

mongo_url <- Sys.getenv("MONGODB_URI")
db_name <- Sys.getenv("DB_NAME", "final_project_db")
collection_name <- Sys.getenv("COLLECTION_NAME", "survey_responses")

# Connect to Mongo
con <- mongo(collection = collection_name, db = db_name, url = mongo_url)

# Fetch data
docs <- con$find()

# Flatten expenses into columns
if ("expenses" %in% names(docs)) {
  exp_df <- bind_cols(docs$expenses)
  names(exp_df) <- paste0("exp_", names(exp_df))
  docs$expenses <- NULL
  df <- bind_cols(docs, exp_df)
} else {
  df <- docs
}

# Save to CSV
dir.create("exports", showWarnings = FALSE)
write_csv(df, "exports/survey_data_r.csv")

print(head(df))
