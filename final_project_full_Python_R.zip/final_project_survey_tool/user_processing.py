from dataclasses import dataclass, asdict
from typing import Dict, Any, List
import pandas as pd
from pymongo import MongoClient
from dotenv import load_dotenv
import os

load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI")
DB_NAME = os.getenv("DB_NAME", "final_project_db")
COLLECTION_NAME = os.getenv("COLLECTION_NAME", "survey_responses")

@dataclass
class User:
    name: str
    age: int
    gender: str
    total_income: float
    expenses: Dict[str, float]

    @staticmethod
    def from_mongo(doc: Dict[str, Any]) -> "User":
        return User(
            name=doc.get("name") or "",
            age=int(doc.get("age", 0)),
            gender=str(doc.get("gender") or ""),
            total_income=float(doc.get("total_income", 0.0)),
            expenses={k: float(v) for k, v in (doc.get("expenses") or {}).items()}
        )

def fetch_users_from_mongo() -> List[User]:
    client = MongoClient(MONGODB_URI)
    col = client[DB_NAME][COLLECTION_NAME]
    docs = list(col.find({}))
    return [User.from_mongo(d) for d in docs]

def users_to_csv(csv_path: str) -> pd.DataFrame:
    users = fetch_users_from_mongo()
    # Normalize: flatten expense dict
    rows = []
    for u in users:
        base = {
            "name": u.name,
            "age": u.age,
            "gender": u.gender,
            "total_income": u.total_income,
        }
        if u.expenses:
            for k, v in u.expenses.items():
                base[f"exp_{k}"] = v
        rows.append(base)
    df = pd.DataFrame(rows)
    df.to_csv(csv_path, index=False)
    return df

if __name__ == "__main__":
    os.makedirs("exports", exist_ok=True)
    df = users_to_csv("exports/survey_data.csv")
    print(f"Wrote {len(df)} rows to exports/survey_data.csv")
